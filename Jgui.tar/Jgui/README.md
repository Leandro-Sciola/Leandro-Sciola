
# Jgui (GTK / Javascript GUI)

### Requirements: GJS (Linux)

root@debian:/home/debian# **apt install gjs**

root@debian:/home/debian# **apt install gir1.2-soup-2.4**

### To run the demo:

Download the [piano.sh](https://raw.githubusercontent.com/sciola-framework/Labs/main/Jgui/piano.sh) file and run in the terminal:

debian@debian:~$ **sh piano.sh**

<img src="printscreen.png">
