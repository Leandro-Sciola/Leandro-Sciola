#!/bin/bash

cd /tmp

if [ ! -f "Piano.js" ]; then
    wget -q --show-progress https://raw.githubusercontent.com/sciola-framework/Labs/main/Jgui/Piano.js
fi

if [ ! -f "Jgui.js" ]; then
    wget -q --show-progress https://raw.githubusercontent.com/sciola-framework/Labs/main/Jgui/Jgui.js
fi

gjs Piano.js
